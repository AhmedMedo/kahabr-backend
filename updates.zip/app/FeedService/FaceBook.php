<?php namespace App\FeedService;
/**
 * Created by PhpStorm.
 * User: medo
 * Date: 26-Sep-16
 * Time: 1:30 PM
 */
use App\Feed;
use App\News;
use Carbon\Carbon;



class FaceBook
{





    public  function Start($feed){
        $news=$this->GetFaceBookPosts($feed);
        $this->SaveNews($news,$feed);
        return count($news);


    }



    public function GetFaceBookPosts($feed)
    {
        $page_news=[];
        $last_title=$this->GetLastTitle($feed);
        $fb = App('SammyK\LaravelFacebookSdk\LaravelFacebookSdk');

        $fb->setDefaultAccessToken(env('FACEBOOK_APP_TOKEN'));
        try {
            $page_title=$feed->link.'/posts?limit='.config('khabar.facebook_limit');
            $response = $fb->get($page_title);
        } catch (\Facebook\Exceptions\FacebookSDKException $e) {
            return 0;

        }


        $PostsNode = $response->getGraphEdge();
        foreach ($PostsNode as $node) {
            # code...
            $title = isset($node['message']) ? $node['message'] : $node['story'];
            //echo var_dump($node['created_time']).'<br>';
            $time = $node['created_time'];
            $date= $time->format('Y-m-d H:i:s');
            $date=Carbon::createFromFormat('Y-m-d H:i:s', $date);
            $date=$date->subHours($feed->offset);

            //extract image
            $id = $node['id'];
            try {
                $post_response = $fb->get($id . '?fields=full_picture,link');
            } catch (\Facebook\Exceptions\FacebookSDKException $e) {


            }

            $data = $post_response->getGraphNode();
            if (isset($data['full_picture'])) {
                $img= $data['full_picture'] ;
            } else {
                $img = null;

            }
            if(isset($data['link']))
            {
                $link=$data['link'];
            }else{
                $link='https://www.facebook.com/'.$id;
            }


            if($title != $last_title)
            {
                array_push($page_news,[
                    'title' =>$title,
                    'date' => $date,
                    'link' =>$link,
                    'image' =>$img

                ]);

            }else{
                break;
            }



        }

        return array_reverse($page_news);


    }




    public  function  SaveNews($page_news,$feed)
    {
        foreach ($page_news as $news)
        {
            $saved_news=new News([
                'title'       =>$news['title'],
                'search_column'=>$news['title'],
                'link' 		  =>$news['link'],
                'imglink'     =>$news['image'],
                'date'        =>$news['date'],
                'lock'        =>1
            ]);


            //echo $item->title.'</br>';
            try{
                $feed->news()->save($saved_news);
            }catch(\Exception $e)

            {

            }

        }
    }

    


    private function GetLastTitle($feed)
    {
        try{
            return $feed->news->last()->title;

        }catch (\Exception $e)
        {
            return null;
        }

    }


}