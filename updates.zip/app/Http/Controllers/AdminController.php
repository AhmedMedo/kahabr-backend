<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Feed;
use App\News;
use Validator;
use DB;
use Hash;
use Auth;
use Yajra\Datatables\Datatables;
use Illuminate\Http\Request;
use Illuminate\Contracts\Auth\Registrar;
use App\User;
use App\UserPrefs;
use App\Http\Controllers\Controller;
use Excel;
use Image;
use App\FeedService\FeedService;
use Session;


class AdminController extends Controller
{


    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
        $this->middleware('IfPassWdChanged');
    }

    /**
     * Display a listing of the resource and all statistics of news and feeds
     *
     * @return Response
     */
    public function index()
    {

        // $feeds=Feed::orderBy('id','ASC')->get();
        // $type=DB::table('feeds')->distinct()->lists('type');
        // $topics=DB::table('feeds')->distinct()->lists('topics');
        // $languages=lang();
        // $countries=countries();
        $number_of_feeds = Feed::count();
        $number_of_news = News::count();
        $number_of_mobile_users = UserPrefs::count();


        return view('admin.dashboard', compact(

            'number_of_feeds', 'number_of_news', 'number_of_mobile_users'
        ));

    }




    // public function ShowFeeds()
    // {
    // 	//$feeds=Feed::all;
    // 	//$feeds->setPath('');

    // 	$type=DB::table('feeds')->distinct()->lists('type');
    // 	$topics=DB::table('feeds')->distinct()->lists('topics');
    // 	$languages=config('khabar.languages');
    // 	$countries=config('khabar.all_countries');


    // 	return view('admin.feeds',compact('feeds','languages','type','topics','countries'));
    // }


    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
        return view('admin.newfeed');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store(Request $request)
    {


        //store all feeds
        $v = Validator::make($request->all(), [
            'link' => 'unique:feeds',
        ]);

        if ($v->fails()) {
            return redirect()->back()->withErrors($v->errors());
        }


        if ($request->hasFile('icon')) {
            $icon = $request->file('icon');
            $name = $icon->getClientOriginalName();
            // $icon->move('icons',$name);
            $image = Image::make($request->file('icon'));
            $image->resize(80, 80);
            $path = 'images/feedicons/' . $name;
            $image->save($path);


        } else {

            $path = 'images/khabar.png';
        }

        //check new topic and type
        $type = $request->has('newtype') ? $request->newtype : $request->type;
        $topic = $request->has('newtopic') ? $request->newtopic : $request->topic;


        try {


            Feed::create([
                'title' => trim($request->title),
                'subtitle' => !empty($request->subtitle) ? $request->subtitle : null,
                'country' => $request->country,
                'language' => $request->lang,
                'type' => $type,
                'topics' => $topic,
                'link' => trim($request->link),
                'offset' => $request->offset,
                'protocol' => $request->protocol,
                'status' => $request->status,
                'img' => $path
            ]);


        } catch (\Exception $e) {
            return redirect('/admin/feeds');
        }


        \Session::flash('message', 'Feed successfully added.');
        return redirect()->back();


    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        //find the feed and go to the edit page
        $feed = Feed::findOrFail($id);
        $type = DB::table('feeds')->distinct()->lists('type');
        $topics = DB::table('feeds')->distinct()->lists('topics');
        $languages = config('khabar.languages');
        $countries = config('khabar.all_countries');
        return view('admin.editfeed', compact('feed', 'type', 'topics', 'languages', 'countries'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
        $feed = Feed::findOrFail($id);
        if ($request->hasFile('icon')) {
            $name = $request->file('icon')->getClientOriginalName();
            $image = Image::make($request->file('icon'));
            $image->resize(80, 80);
            $path = 'images/feedicons/' . $name;
            $image->save('images/feedicons/' . $name);

        }

        //check new topic and type
        $type = $request->has('newtype') ? $request->newtype : $request->type;
        $topic = $request->has('newtopic') ? $request->newtopic : $request->topic;

        //update news to lock 0 if satatus is draft
        if ($request->status == 0) {
            $feed->news()->update(array('lock' => 0));
        } else {

            $feed->news()->update(array('lock' => 1));

        }

        $feed->update([
            'title' => trim($request->title),
            'subtitle' => !empty($request->subtitle) ? $request->subtitle : null,
            'country' => $request->country,
            'language' => $request->lang,
            'type' => $type,
            'topics' => $topic,
            'link' => trim($request->link),
            'offset' => $request->offset,
            'status' => $request->status,
            'img' => $path


        ]);
        \Session::flash('message', 'Feed successfully updated.');
        return redirect('/admin/feeds');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        //
        $feed = Feed::findOrFail($id);
        $feed->delete();
        \Session::flash('deletemessage', 'Feed successfully deleted.');
        return redirect()->back();
    }


    /* functions for admin control*/


    /*
        view edit page for the user
    */
    public function viewEdit()
    {
        return view('auth.edit');
    }

    public function PostEdit(Request $request)
    {
        $v = Validator::make($request->all(), [
            'name' => 'required|',
            'email' => 'required|email',
            'password' => 'min:6|same:password_confirmation'
        ]);

        if ($v->fails()) {
            return redirect()->back()->withErrors($v->errors());
        }

        Auth::user()->name = $request->name;
        Auth::user()->email = $request->email;
        Auth::user()->password = Hash::make($request->password);
        Auth::user()->save();
        Auth::logout();
        Session::remove('updated');
        return redirect('/');
    }

    /*Create new admin by the super admin*/

    public function newAdmin()
    {
        return view('admin.newadmin');
    }

    public function postAdmin(Request $request)
    {
        $v = Validator::make($request->all(), [
            'name' => 'unique:users',
            'email' => 'unique:users'
        ]);

        if ($v->fails()) {
            return redirect()->back()->withErrors($v->errors());
        }

        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->role = $request->role;
        $user->save();
        \Session::flash('message', 'New admin successfully added.');

        return redirect('/admin/adminmembers');
    }


    public function AdminMembers()
    {
        $users = User::where('role', '!=', 'superadmin')->get();
        //$users=User::all();

        return view('admin.adminmembers', compact('users'));
    }

    public function DeleteMember($id)
    {
        DB::delete('delete from users where id = ?', [$id]);
        \Session::flash('deletemessage', 'Member successfully deleted.');

        return redirect()->back();
        //echo $id;

    }


    public function EditMember($id)
    {
        $user = User::find($id);
        return view('admin.updatemember', compact('user'));
    }

    public function UpdateMember(Request $request, $id)
    {

        $user = User::find($id);
        if ($request->has('name')) {

        }

        $user->name = $request->name;
        $user->email = $request->email;
        if ($request->has('password')) {
            $user->password = Hash::make($request->password);
        }
        if ($request->has('role')) {
            $user->role = $request->role;
        }

        $user->save();
        \Session::flash('message', 'Member successfully updated');
        return redirect('/admin/adminmembers');
    }


    public function CheckLink()
    {
        $link = $_POST['link'];

        $count = Feed::where('link', $link)->count();
        return response($count);
    }


}
