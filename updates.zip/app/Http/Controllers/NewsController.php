<?php namespace App\Http\Controllers;

use App\FeedService\FaceBook;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Feed;
use App\News;
use Yajra\Datatables\Datatables;
use Illuminate\Http\Request;
use DB;
use GuzzleHttp\Client;
use App\BackupService\BackupService;
use App\FeedService\FeedService;
use Carbon\Carbon;
use Cache;
use View;

class NewsController extends Controller
{


    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        //show news of a feed
        $feed = Feed::find($id);
        $all_news = $feed->news()->orderBy('date', 'desc')->paginate(10);
        $all_news->setPath('');
        $feed_title = $feed->title;
        return view('admin.news', compact('all_news', 'feed_title'));
    }

    public function destroy($id)
    {
        //
        $news = News::findOrFail($id);
        $news->delete();
        return redirect()->back();
    }


    /**
     * get last news  of a a specific feed determined by id
     * method respond to  AJAX request
     * @param  int $id of feed to be parsed and get last news
     * @return Response
     */

    public function FeedParse()
    {
        $id = $_POST['id'];
        $single_feed_parse = new FeedService();
        $count = $single_feed_parse->SingleFeedParse($id);
        return response($count);
    }

}